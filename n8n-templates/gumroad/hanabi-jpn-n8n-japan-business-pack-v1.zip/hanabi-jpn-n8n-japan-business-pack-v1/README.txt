================================================================
  n8n Japan Business Automation Pack v1.0
  by hanabi-jpn
================================================================

Thank you for your purchase!

This pack contains 5 production-ready n8n workflow templates
designed for businesses operating in Japan.


CONTENTS
--------
  workflows/
    chatwork-notification.json    ChatWork multi-source alert router
    stripe-payment-flow.json      Stripe Japan payment processing
    social-media-scheduler.json   X/Instagram/LINE cross-poster
    ga4-weekly-report.json        GA4 + Search Console weekly report
    kintone-sync.json             kintone <-> Google Sheets sync

  setup-guide.md                  Detailed setup instructions
  README.txt                      This file


QUICK START (5 minutes)
-----------------------
1. Open your n8n instance (self-hosted or cloud)
2. Create a new workflow
3. Click the menu (three dots, top right) > "Import from File"
4. Select any .json file from the workflows/ folder
5. Set your environment variables (see setup-guide.md)
6. Test the workflow with "Execute Workflow"
7. Toggle the workflow to Active

For detailed instructions, open setup-guide.md.


REQUIRED ENVIRONMENT VARIABLES (by template)
---------------------------------------------

ChatWork Notification Hub:
  CHATWORK_API_TOKEN
  CHATWORK_DEPLOY_ROOM_ID
  CHATWORK_ERROR_ROOM_ID
  CHATWORK_TEAM_ROOM_ID
  CHATWORK_ONCALL_ACCOUNT_ID

Stripe Japan Payment Flow:
  STRIPE_WEBHOOK_SECRET
  CHATWORK_API_TOKEN
  CHATWORK_SALES_ROOM_ID
  CHATWORK_ONCALL_ACCOUNT_ID
  GOOGLE_SHEET_ID

Social Media Cross-Post Scheduler:
  CONTENT_SHEET_ID
  X_API_KEY / X_API_SECRET
  INSTAGRAM_BUSINESS_ACCOUNT_ID
  INSTAGRAM_ACCESS_TOKEN
  LINE_CHANNEL_ACCESS_TOKEN
  CHATWORK_API_TOKEN
  CHATWORK_MARKETING_ROOM_ID

GA4 Weekly Report:
  GA4_PROPERTY_ID
  GSC_SITE_URL
  CHATWORK_API_TOKEN
  CHATWORK_MARKETING_ROOM_ID

kintone Bi-Directional Sync:
  KINTONE_DOMAIN
  KINTONE_API_TOKEN
  KINTONE_APP_ID
  SYNC_SHEET_ID
  CHATWORK_API_TOKEN
  CHATWORK_OPS_ROOM_ID


SUPPORT
-------
  Email:  hanabi.jpn.dev@gmail.com
  GitHub: github.com/hanabi-jpn
  X:      @hanabi_jpn

If something doesn't work, check setup-guide.md first. If you're
still stuck, email us and we'll help you debug it.

30-day money-back guarantee. No questions asked.


LICENSE
-------
You may use these templates in your own projects and client
projects. You may not redistribute the template files as-is or
include them in a competing template pack for sale.

Copyright 2026 hanabi-jpn. All rights reserved.
================================================================
